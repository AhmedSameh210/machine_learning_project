#!/usr/bin/env python
# coding: utf-8

# # Data Preparation (Feature Engineering)

# In[ ]:


pip install Pillow


# In[ ]:


import pandas as pd
from PIL import Image
import requests
from io import BytesIO
import numpy as np

get_ipython().run_line_magic('matplotlib', 'inline')


# In[ ]:


inputfile = 'SongPopularity.csv'

df = pd.read_csv(inputfile)


# ## Spotify Scraping

# In[ ]:


pip install spotipy


# In[ ]:


import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

# Replace 'your_client_id' and 'your_client_secret' with your actual credentials
client_id = '8511883112844fcc9960cf1da4699dae'
client_secret = '5770b9745bfc49c2b0fea6cb1dfe4c0d'

# Authenticate with Spotify API
client_credentials_manager = SpotifyClientCredentials(client_id=client_id, client_secret=client_secret)
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)


# In[ ]:


def get_song_data(song_uri):
    try:
        # Get track info using URI
        track_info = sp.track(song_uri)

        # Extract relevant data from track_info
        song_data = {
            # 'name': track_info['name'],
            # 'artist': track_info['artists'][0]['name'],
            # 'album': track_info['album']['name'],
            # 'release_date': track_info['album']['release_date'],
            # 'popularity': track_info['popularity'],
            'avaliable_markets':track_info['available_markets'],
            'is_local':track_info['is_local']

        }

        return song_data

    except Exception as e:
        print(f"Error: {e}")
        return None


# In[ ]:


urls = df['Spotify URI'].tolist()
urls


# In[ ]:


from tqdm import tqdm

scraped_data = []
# Create tqdm wrapper around urls to track progress
for url in tqdm(urls[2456:4994], desc="Scraping Songs"):
    song_data = get_song_data(url)
    if song_data:
        scraped_data.append(song_data)


# In[ ]:


# Convert scraped data to DataFrame
scraped_df = pd.DataFrame(scraped_data)

# Save DataFrame to CSV
scraped_df.to_csv('spotify_scrapping4.csv', index=False)


# ## Image To Text

# In[ ]:


import requests
from PIL import Image
from transformers import BlipProcessor, BlipForConditionalGeneration

processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-large")
model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-large").to("cuda")


# In[ ]:


urls=df['Song Image'].tolist()


# In[ ]:


output_descriptions=[]
for url in urls:

    raw_image = Image.open(requests.get(url, stream=True).raw).convert('RGB')


    inputs = processor(raw_image, return_tensors="pt").to("cuda")
    out = model.generate(**inputs)
    desc = processor.decode(out[0], skip_special_tokens=True)


    output_descriptions.append(desc)


# In[ ]:


import csv

csv_file_path = 'images_desc.csv'


# Open CSV file in write mode with UTF-8 encoding
with open(csv_file_path, 'w', newline='', encoding='utf-8') as csv_file:
    writer = csv.writer(csv_file)  # Create a CSV writer
    writer.writerow(['image_description'])  # Write column header
    for value in output_descriptions:
        writer.writerow([value])


# ## Artist Rank Scrapping (https://www.songkick.com/leaderboards/popular_artists?page=4)

# In[ ]:


pip install beautifulsoup4


# In[ ]:


def extract_artist_rankings(url):

    response = requests.get(url)
    if response.status_code == 200:

        soup = BeautifulSoup(response.content, 'html.parser')
        artist_rows = soup.find_all('tr')[1:]  # Start from index 1 to skip the header row

        rankings = []

        for row in artist_rows:
            rank = row.find('td', class_='index').text.strip()

            name = row.find('td', class_='name').a.text.strip()

            rankings.append({'Rank': rank, 'Name': name})

        return rankings
    else:
        print(f"Failed to retrieve data from the URL: {url}")
        return []


# In[ ]:


def save_artist_rankings_to_csv(data, filename):

    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=['Rank', 'Name'])
        writer.writeheader()
        writer.writerows(data)


# In[ ]:


urls = [
    "https://www.songkick.com/leaderboards/popular_artists",
    "https://www.songkick.com/leaderboards/popular_artists?page=2",
    "https://www.songkick.com/leaderboards/popular_artists?page=3",
    "https://www.songkick.com/leaderboards/popular_artists?page=4",
    "https://www.songkick.com/leaderboards/popular_artists?page=5"
]



all_rankings = []

# Scrape each URL and extract artist rankings
for url in urls:
    rankings = extract_artist_rankings(url)
    all_rankings.extend(rankings)

# Save the artist rankings to a CSV file
save_artist_rankings_to_csv(all_rankings, 'artist_rankings.csv')


# ## Song Name is Catchy or Not using Prompt Engineering

# In[ ]:


from transformers import AutoModelForSeq2SeqLM
from transformers import AutoTokenizer
from transformers import GenerationConfig
import os
import torch


# In[ ]:


model_name='google/flan-t5-xl'

model = AutoModelForSeq2SeqLM.from_pretrained(model_name)


# In[ ]:


tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)


# In[ ]:


sentence = "What time is it, Tom?"

sentence_encoded = tokenizer(sentence, return_tensors='pt')

sentence_decoded = tokenizer.decode(
        sentence_encoded["input_ids"][0],
        skip_special_tokens=True
    )

print('ENCODED SENTENCE:')
print(sentence_encoded["input_ids"][0])
print('\nDECODED SENTENCE:')
print(sentence_decoded)


# In[ ]:


def make_prompt(examples, testEx):
    prompt = ""
    for i in range(len(examples)):
        prompt += f"""(be strict) Song Name : {examples[i][0]}\n\nIs it Catchy ? {examples[i][1]}\n\n"""
    prompt += f"""Song Name : {testEx}\n\nIs it Catchy ?"""
    return prompt


# In[ ]:


examples = [
    ["I Need You", "Catchy"],
    ["Hurt", "Catchy"],
    ["You Take My Breath Away - Mono Version", "Not Catchy"],
    ["If I Give My Heart to You (with The Mellomen)", "Not Catchy"],
    ["Throwing It All Away - 2007 Remaster", "Not Catchy"],
    ["Does Your Chewing Gum Lose Its Flavour (On The Bedpost Overnight)", "Not Catchy"],
    ["The Rock And Roll Waltz", "Not Catchy"],
]


# In[ ]:


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
#tokenizer.to(device)

# Assuming df is your DataFrame
outputs = []
for i in range(rows[0]):
    testEx = df.iloc[i]
    one_shot_prompt = make_prompt(examples, testEx)
    inputs = tokenizer(one_shot_prompt, return_tensors='pt').to(device)
    output = tokenizer.decode(
        model.generate(
            inputs["input_ids"],
            max_new_tokens=200,
        )[0],
        skip_special_tokens=True
    )
    print(f"I : {i} output : {output}")
    if output == "Yes":
        outputs.append(1)
    else:
        outputs.append(0)


# In[ ]:


DataFrame=pd.read_csv("/content/SongPopularity.csv")


# In[ ]:


DataFrame["isItCatchy"]=outputs


# In[ ]:


DataFrame.to_excel("Song_with_isItCatchy.xlsx")


# ## Date Handling & new date features

# In[ ]:


# Conver Date to dd-mm-year
def convert_date(date_str):
    # Check if the string is in the format 'yyyy-mm'
    if len(date_str) == 7 and date_str[4] == '-':
      #yy-mm only in csv it's found the day to be 01
        return '01-' + date_str[5:] + '-' + date_str[:4]
    # Check if the string is in the format 'yyyy-mm-dd'
    elif len(date_str) == 10 and date_str[4] == '-' and date_str[7] == '-':
        return date_str[8:] + '-' + date_str[5:7] + '-' + date_str[:4]
    # Check if the string is in the format 'm/d/yyyy'
    elif '/' in date_str:
        return pd.to_datetime(date_str).strftime('%d-%m-%Y')
    else:
        return date_str  # year only i will leave it as it is


# In[ ]:


df['Album Release Date'] = df['Album Release Date'].apply(convert_date)


# In[ ]:


# extract year from date
def extract_year(date_str):
    # Check which format to extract year only
    if '-' in date_str:
        return int(date_str.split('-')[-1])
    else:
        return int(date_str)



# Extract year from each date
df['year'] = df['Album Release Date'].apply(extract_year)


# Sort
df = df.sort_values(by='year')


# In[ ]:


df.head()


# In[ ]:



# Function to extract year, month, and day from date
def extract_date_parts(date_str):
    if '-' in date_str:
        parts = date_str.split('-')
        return int(parts[0]), int(parts[1]), int(parts[2])
    else:
        return None, None, None

# Function to calculate average day and month from surrounding 5 rows
def calculate_average_date(index, df):
    start_index = max(0, index - 2)
    end_index = min(len(df), index + 3)
    valid_dates = [(d, m) for d, m, _ in [extract_date_parts(date) for date in df.iloc[start_index:end_index]['Album Release Date']] if d is not None and m is not None]
    if valid_dates:
        avg_day = sum(d for d, _ in valid_dates) // len(valid_dates)
        avg_month = sum(m for _, m in valid_dates) // len(valid_dates)
        return avg_day, avg_month
    else:
        print(index)
        return 1, 1  # Default day and month if no valid dates found


# Iterate through rows with only year, calculate average day and month, and assign them
for index, row in df.iterrows():
    if '-' not in row['Album Release Date']:
        avg_day, avg_month = calculate_average_date(index, df)
        if avg_day is not None and avg_month is not None:
            df.at[index, 'Album Release Date'] = f'{avg_day}-{avg_month}-{row["Album Release Date"]}'


# In[ ]:


# Convert modified rows to 'd-m-yyyy' format
df['Album Release Date'] = pd.to_datetime(df['Album Release Date'])


# In[ ]:


# Replace 'Hot100 Ranking Year' column with the maximum of 'year'
df['Hot100 Ranking Year'] = df[['year', 'Hot100 Ranking Year']].max(axis=1)


# In[ ]:



# Function to determine the decade
def determine_decade(year):
  if year < 1920:
    return "Old"
  elif year >= 1920 and year< 1930:
    return "Twenties"
  elif year >= 1930 and year <1940:
    return "Thirties"
  elif year >= 1940 and year <1950:
    return "Fourties"
  elif year >= 1950 and year < 1960:
    return "Fifties"
  elif year >= 1960 and year<1970:
    return "Sixties"
  elif year >= 1970 and year <1980:
    return "Seventies"
  elif year >=1980 and year <1990:
    return "Eighties"
  elif year >= 1990 and year < 2000:
    return "Nighnties"
  elif year >= 2000:
    return "new millennium"


# In[ ]:



df['Decade'] = df['year'].apply(determine_decade)


# In[ ]:


df.head()


# In[ ]:


def get_season(month):
    if 3 <= month <= 5:
        return 'Spring'
    elif 6 <= month <= 8:
        return 'Summer'
    elif 9 <= month <= 11:
        return 'Autumn'
    else:
        return 'Winter'


# In[ ]:


df['Month'] = df['Album Release Date'].dt.month
df['Season'] = df['Month'].apply(get_season)


# In[ ]:


df.info()


# In[ ]:



df = df.sort_index()


# In[ ]:


Final = df[['Song','Album Release Date','Hot100 Ranking Year','Decade','Season']]


# In[ ]:


Final.head()


# In[ ]:


Final.to_csv('Popularity_Spotify2.csv', index=False)


# ## Genres Handling & Weights

# In[ ]:


def Convert(entry) -> set:
    my_set = set()
    flag = False
    current_word = ""
    for j in range(1, len(entry)):
        currnet_char = entry[j]
        if(currnet_char == '\'' and flag):
            my_set.add(current_word)
            current_word = ""
            flag = False
        elif(currnet_char == '\''):
            flag = True
        elif j != len(entry) - 1  and currnet_char != ',':
            current_word += currnet_char
    return my_set


# In[ ]:


sub_data = pd.DataFrame({'Artist Names':df['Artist Names'],'Artist(s) Genres':df['Artist(s) Genres']})

dic = {}

for i in range(0,len(sub_data)):

    entry_of_artists = tuple(Convert(sub_data.iloc[i,0]))
    entry_of_artists_genres = Convert(sub_data.iloc[i,1])

    if dic.get(entry_of_artists) == None:
        dic.update({entry_of_artists : entry_of_artists_genres})
    else:
        dic[entry_of_artists] = entry_of_artists_genres.union(dic[entry_of_artists])
    df['Artist(s) Genres'].iloc[i] = dic[entry_of_artists]


# In[ ]:


list_of_genres_count = []

for element in (df['Artist(s) Genres']):
    list_of_genres_count.append(len(element))


# In[ ]:


genres_freq = {}
weight_column = [0 for _ in range(0,len(df['Artist(s) Genres']))]
for entry in df['Artist(s) Genres']:
    for gener in entry:
        if genres_freq.get(gener) == None:
            genres_freq.update({gener:1})
        else:
            genres_freq[gener] += 1

for i,entry in enumerate(df['Artist(s) Genres']):
    for gener in entry:
        weight_column[i] += genres_freq[gener]


# In[ ]:


with open('abdelrhman&nour.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Song', 'Artist(s) Genres','Genres count','Weight','total weight of genres'])  # Writing header
    for item1, item2, item3, item4, item5 in zip(list(df['Song']), df["Artist(s) Genres"], list_of_genres_count, weight_column, [x * y for x, y in zip(list_of_genres_count, weight_column)]):
        writer.writerow([item1, item2, item3, item4, item5])


# ## Top Albums Scrapping (https://chartmasters.org/top-album/?slk=ql)

# In[ ]:


from bs4 import BeautifulSoup


# In[ ]:


html_source="""Write here the HTML Body for each page"""


# In[ ]:


soup = BeautifulSoup(html_source, 'html.parser')


# In[ ]:


table = soup.find('tbody')


# In[ ]:


def Convert_htmlTableToCsv(table):
    headers = [header.text.strip() for header in table.find_all('th')]
    rows = []
    for row in table.find_all('tr'):
        cells = row.find_all('td')
        if cells:
            rows.append([cell.text.strip() for cell in cells])
    df=pd.DataFrame(rows).drop([2],axis=1)
    return df

def concat(oldDF,NewDf)
    df=pd.concat([NewDf,oldDF],axis=0).reset_index().drop(["index"],axis=1)
    return df


# ## Cluster on Genres

# In[ ]:


df1=pd.read_csv("/content/Popularity_Spotify2 (1).csv")
df2=pd.read_csv("/content/abdelrhman&nour (1).csv")
df2["Album Release Date"]=df["Album Release Date"]


# In[ ]:


df2.head()


# In[ ]:


df1.head()


# In[ ]:


DfExpanded=pd.DataFrame(df2)
df2["Album Release Date"] = pd.to_datetime(df2["Album Release Date"])
DfExpanded["Song"]=df2["Song"]
DfExpanded["Day"]=df2["Album Release Date"].dt.day
DfExpanded["Month"]=df2["Album Release Date"].dt.month
DfExpanded["Year"]=df2["Album Release Date"].dt.year
DfExpanded=DfExpanded.drop(["Artist(s) Genres","Album Release Date"],axis=1)


# In[ ]:


from sklearn.preprocessing import StandardScaler
x=np.array(DfExpanded.drop(["Song"],axis=1))
scaler = StandardScaler()
scaled_features = scaler.fit_transform(x)


# In[ ]:


from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=20)


# In[ ]:



kmeans.fit(scaled_features)


# In[ ]:


centroids = kmeans.cluster_centers_
labels = kmeans.labels_


# In[ ]:


DfExpanded["clusters"]=labels


# In[ ]:


DfExpanded["clusters"].hist()


# In[ ]:


DfExpanded.drop(["Genres count","Weight","total weight of genres","Day","Month","Year"],axis=1).to_csv("clusterData")


# ## Data Concatenation

# In[ ]:


def count_words_and_characters(sentence):
    # Count words
    words = sentence.split()
    num_words = len(words)
    num_characters = len(sentence)
    return num_words, num_characters


# In[ ]:


df['number of words of the song name'], df['number of characters of the song name'] = zip(*df['Song'].apply(count_words_and_characters))


# In[ ]:


df.head()


# In[ ]:


df['Popularity']


# In[ ]:


scraped_data=pd.read_csv("/content/spotify_scrapping (1).csv")
scraped_data.head()


# In[ ]:


scraped_data=scraped_data.rename(columns={'name': 'Song'})


# In[ ]:


needed_from_scrapping=scraped_data.drop(['artist','album','release_date','popularity'], axis=1)


# In[ ]:


df['avaliable_markets'] = scraped_data['avaliable_markets'].tolist()
df['is_local'] = scraped_data['is_local'].tolist()


# In[ ]:


df.shape


# In[ ]:


df.head()


# In[ ]:


df['avaliable_markets'].isnull().sum()


# In[ ]:


import ast
def process_list_string(s):
    try:

        lst = ast.literal_eval(s)

        num_elements = len(lst)
        return lst, num_elements
    except (SyntaxError, ValueError):

        return [], 0


# Apply the function to each row in the DataFrame
df[['avaliable_markets list', 'num_of_song_avaliable_markets']] = df['avaliable_markets'].apply(lambda x: pd.Series(process_list_string(x)))


# In[ ]:


df.head()


# In[ ]:


df.drop(['avaliable_markets list','avaliable_markets'], axis=1, inplace=True)


# In[ ]:


df.head()


# In[ ]:


df.shape


# In[ ]:


import numpy as np
data=df['Song Length(ms)'].tolist()
mean_value = np.mean(data)
median_value = np.median(data)
std_deviation = np.std(data)

print("Mean:", mean_value)
print("Median:", median_value)
print("Standard Deviation:", std_deviation)


# In[ ]:


# Automatically calculate thresholds based on statistical measures
large_threshold = mean_value + 1.5 * std_deviation
small_threshold = mean_value - 1.5 * std_deviation

# Classify times based on calculated thresholds
classified_times = []

for value in data:
    if value >= large_threshold:
        classified_times.append("large_time")
    elif value >= small_threshold:
        classified_times.append("average_time")
    else:
        classified_times.append("small_time")

print("Large Time Threshold:", large_threshold)
print("Small Time Threshold:", small_threshold)
print("Classified Times:", classified_times)


# In[ ]:


df['Duration Category']=classified_times


# In[ ]:


df.shape


# In[ ]:


df.head(10)


# In[ ]:


# Define a function to categorize values
def categorize_potential(value):
    if value > 50:
        return "True"
    else:
        return "False"

# Apply the function to create a new column 'Potential'
df['has_Potential'] = df['Hot100 Rank'].apply(categorize_potential)


# In[ ]:


df.head()


# In[ ]:


def check_colorfulness(image):
    # Convert image to numpy array
    image_array = np.array(image)

    # Calculate standard deviation of RGB values
    std_dev = np.std(image_array, axis=(0,1)).mean()

    # Define a threshold for colorfulness
    color_threshold = 50.0  # 81 is very colorful

    # Determine if the image is colorful based on standard deviation
    return std_dev > color_threshold

def extract_color_values(image):
    # Convert image to numpy array
    image_array = np.array(image)

    # Flatten the array to get all RGB values
    flattened = image_array.reshape(-1, 3)

    # Get unique RGB values and their counts
    unique_colors, counts = np.unique(flattened, axis=0, return_counts=True)

    # Sort colors by frequency (most common colors first)
    sorted_colors = sorted(zip(unique_colors, counts), key=lambda x: -x[1])

    # Return the top color values (RGB) and their frequencies
    return sorted_colors[:5]  # Return top 5 colors


# In[ ]:


import pandas as pd
import requests
from PIL import Image
from io import BytesIO
from tqdm import tqdm

def process_image(url):
    try:
        # Request image from URL
        response = requests.get(url)
        image = Image.open(BytesIO(response.content))

        # Check if the image is colorful
        is_colorful_image = check_colorfulness(image)

        # Get color values
        color_values = extract_color_values(image)

        return is_colorful_image, color_values

    except Exception as e:
        print(f"Error processing image from {url}: {e}")
        return None, None


urls = df['Song Image'].tolist()

is_colorful = []
color_values = []

for url in tqdm(urls, desc="Processing images"):
    is_colorful_image, color_vals = process_image(url)
    is_colorful.append(is_colorful_image)
    color_values.append(color_vals)

# Add results to DataFrame
df['is_colorful'] = is_colorful
df['color_values'] = color_values


# In[ ]:


image_desc = pd.read_csv('/content/images_desc.csv')


# In[ ]:


image_desc.head()


# In[ ]:


image_desc.shape


# In[ ]:


df.shape


# In[ ]:


df['image_description']=image_desc['image_description'].tolist()


# In[ ]:


df.head()


# In[ ]:


artist_scraping = pd.read_csv("/content/artist_rankings.csv")


# In[ ]:


artist_scraping.head()


# In[ ]:


topartists=artist_scraping['Name'].tolist()


# In[ ]:


len(topartists)


# In[ ]:


artists=df['Artist Names'].tolist()


# In[ ]:


def extract_artist_names(artist_string):
    # Remove surrounding characters like '[', ']', and whitespace
    cleaned_string = artist_string.strip("[]' ")
    # Split the cleaned string by comma to extract individual artist names
    return [name.strip() for name in cleaned_string.split(",")]

# List to store the results for each artist group
result = []

# Iterate over each artist group in the artists list
for artist_group in artists:
    # Extract artist names from the current artist group
    artist_names = extract_artist_names(artist_group)

    # Check if any artist name is in the topartists list
    # Using a generator expression with any() to check for existence
    found_in_topartists = any(artist in topartists for artist in artist_names)

    # Append the result (True or False) to the results list
    result.append(found_in_topartists)


# In[ ]:


len(result)


# In[ ]:


df['fromTop1000Artist']=result


# In[ ]:


df.head()


# In[ ]:


song_prompting=pd.read_csv("/content/Song_with_isItCatchy.csv")


# In[ ]:


iscatchy=song_prompting['isItCatchy'].tolist()


# In[ ]:


df['isItCatchy']=iscatchy


# In[ ]:


df.head()


# In[ ]:


datecat=pd.read_csv("/content/Popularity_Spotify2 (1).csv")


# In[ ]:


datecat.head(7)


# In[ ]:


datecat.shape


# In[ ]:


updated_dates=datecat['Album Release Date'].tolist()
updatedhot=datecat['Hot100 Ranking Year'].tolist()
decade=datecat['Decade'].tolist()
season=datecat['Season'].tolist()


# In[ ]:


df.drop(['Album Release Date','Hot100 Ranking Year'], axis=1,inplace=True)


# In[ ]:


df['Album Release Date']=updated_dates
df['Hot100 Ranking Year']=updatedhot
df['Decade']=decade
df['Season']=season


# In[ ]:


df.head(7)


# In[ ]:


df.drop(['Unnamed: 0'], axis=1,inplace=True)


# In[ ]:


df.head()


# In[ ]:


def count_words(sentence):
    # Count words in a sentence
    words = sentence.split()
    num_words = len(words)
    return num_words

df['number of song image details'] = df['image_description'].apply(count_words)


# In[ ]:


df.head()


# In[ ]:


generes_handle= pd.read_csv("/content/abdelrhman&nour (1).csv")


# In[ ]:


generes_handle.shape


# In[ ]:


generes_handle.head()


# In[ ]:


df.drop(['Artist(s) Genres'], axis=1,inplace=True)


# In[ ]:


updated_gen=generes_handle['Artist(s) Genres'].tolist()
gen_count=generes_handle['Genres count'].tolist()
weight=generes_handle['Weight'].tolist()
total_weight=generes_handle['total weight of genres'].tolist()


# In[ ]:


df['Artist(s) Genres'] = updated_gen
df['Genres count']=gen_count
df['Weight']=weight
df['total weight of genres']=total_weight


# In[ ]:


df.head()


# In[ ]:


albums_scraped=pd.read_excel("/content/ALL DATE ALBUMS.xlsx")
albums_scraped.head()


# In[ ]:


topalbums=albums_scraped[3].tolist()
albums=df['Album'].tolist()


# In[ ]:


len(topalbums)


# In[ ]:


len(albums)


# In[ ]:


result = []

for album in albums:
    # Check if album is a substring of any string in topalbums
    if any(album in top_album for top_album in topalbums):
        result.append(True)
    else:
        result.append(False)


# In[ ]:


result


# In[ ]:


df['Album_isTop_1810']=result


# In[ ]:


df.head()


# In[ ]:


clusters=pd.read_excel("/content/clusterData.xlsx")


# In[ ]:


clusters.head()


# In[ ]:


clusters_list=clusters['clusters'].tolist()
df['Generes Clusters'] = clusters_list


# In[ ]:


clusters.drop(['Unnamed: 0'] , axis =1 , inplace =True)


# In[ ]:


df.head()


# In[ ]:


df.to_csv("Prepared Song Popularity.csv")


# # EDA (Exploratory Data Analysis)

# In[ ]:


pip install plotly


# In[ ]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import preprocessing
from wordcloud import WordCloud
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots


# In[ ]:


data = pd.read_csv("Prepared Song Popularity.csv")


# In[ ]:


data.head()


# In[ ]:


for column_name in data.columns:
    print(column_name)


# In[ ]:


data.drop(columns=['Unnamed: 0'],inplace=True)


# In[ ]:


data.shape


# In[ ]:


data.info()


# In[ ]:


data.describe()


# In[ ]:


data.isnull().sum()/len(data)*100


# In[ ]:


data['Artist(s) Genres'].fillna('[]', inplace=True)


# In[ ]:


data.isnull().sum()/len(data)*100


# In[ ]:


# Select only numeric columns
numeric_columns = data.select_dtypes(include='number')
correlation_matrix = numeric_columns.corr()
plt.figure(figsize=(20, 16))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Heatmap')
plt.show()


# In[ ]:


get_ipython().system('pip install pandas-profiling')


# In[ ]:


get_ipython().system('pip install markupsafe==2.0.1')


# In[ ]:


pip install pydantic==1.*


# In[ ]:


from pandas_profiling import ProfileReport

# Assuming 'data' is your DataFrame
profile = ProfileReport(data, config_file="")

# Now you can generate the profile report
profile.to_file("data_profile_report.html")


# In[ ]:


profile


# In[ ]:


plt.figure(figsize=(8, 5))
sns.countplot(x="Duration Category",hue='Popularity' ,data=data)


# In[ ]:


plt.figure(figsize=(8, 5))
sns.countplot(x="is_colorful",hue='Popularity' ,data=data)


# In[ ]:


plt.figure(figsize=(8, 5))
sns.countplot(x="isItCatchy",hue='Popularity' ,data=data)


# In[ ]:


plt.figure(figsize=(8, 5))
sns.countplot(x="Season",hue='Popularity' ,data=data)


# In[ ]:


#place ' pop' with 'pop'
genre_counts = {}
for genres_set in data['Artist(s) Genres']:
    genres_list = [genre.strip().lower() for genre in genres_set[1:-1].split(',')]
    genres_list = [genre.replace(" pop", "pop") for genre in genres_list]
    for genre in genres_list:
        if genre in genre_counts:
            genre_counts[genre] += 1
        else:
            genre_counts[genre] = 1

sorted_genre_counts = dict(sorted(genre_counts.items(), key=lambda item: item[1], reverse=True))

top_genres = list(sorted_genre_counts.keys())[:20]
genre_counts_top = {genre: sorted_genre_counts[genre] for genre in top_genres}

plt.figure(figsize=(12, 8))
sns.barplot(x=list(genre_counts_top.values()), y=list(genre_counts_top.keys()), palette="viridis")
plt.xlabel('Frequency')
plt.ylabel('Genre')
plt.title('Top 20 Genres')
plt.show()


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Select only numeric columns
numeric_columns = data.select_dtypes(include='number')
correlation_matrix = numeric_columns.corr()
plt.figure(figsize=(20, 16))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Heatmap')
plt.show()


# In[ ]:


song_length_counts = data['Duration Category'].value_counts().reset_index()
song_length_counts.columns = ['Duration Category', 'Count']

# Calculate average tempo for each song length category
avg_temp = data.groupby('Duration Category')['Tempo'].mean().reset_index()

# Merge counts and average tempo
song_length_data = song_length_counts.merge(avg_temp, on='Duration Category')

fig = px.pie(song_length_data, names='Duration Category', values='Count', hole=0.5,
             labels={'Duration Category': 'Duration Category', 'Count': 'Count'},
             title='Song Length Distribution by Average Temp')
fig.update_traces(hovertemplate='<b>%{label}</b><br>Count: %{value}<br>Avg Temp: %{text}°C',
                  text=song_length_data['Tempo'].round(1))

fig.show()


# In[ ]:


key_counts = data['Key'].value_counts().reset_index()
key_counts.columns = ['Key', 'Count']

# Specify the color you want for each key
color_discrete_map = {
    'C': 'blue',
    'C#': 'green',
    'D': 'red',
    'D#': 'orange',
    'E': 'purple',
    'F': 'cyan',
    'F#': 'magenta',
    'G': 'yellow',
    'G#': 'lime',
    'A': 'pink',
    'A#': 'brown',
    'B': 'grey'
}

fig = px.bar(key_counts, x='Key', y='Count',
             color='Key', color_discrete_map=color_discrete_map,
             labels={'Key': 'Key', 'Count': 'Count'},
             title='Distribution of Songs by Key')
fig.show()


# In[ ]:


plt.figure(figsize=(8, 6))
sns.barplot(x='Mode', y='Popularity', data=data, ci=None, palette=['#FF5733', '#3399FF'])
plt.title('Mean Popularity by Mode')
plt.xlabel('Mode')
plt.ylabel('Mean Popularity')
plt.xticks(ticks=[0, 1], labels=['Mode 0', 'Mode 1'])
plt.show()


# In[ ]:


plt.figure(figsize=(10, 6))
sns.countplot(x='Duration Category', hue='Time Signature', data=data, palette='viridis')
plt.title('Distribution of Time Signature by Duration Category')
plt.xlabel('Duration Category')
plt.ylabel('Count')
plt.legend(title='Time Signature')
plt.xticks(rotation=45)
plt.show()


# In[ ]:


plt.figure(figsize=(10, 6))
sns.countplot(x='Genres count', data=data, palette='viridis')
plt.title('Distribution of Genre Counts')
plt.xlabel('Genre Count')
plt.ylabel('Frequency')
plt.show()


# In[ ]:


import plotly.graph_objects as go

# Features to include
features = ['Popularity', 'Acousticness', 'Danceability', 'Energy', 'Instrumentalness', 'Liveness', 'Loudness', 'Speechiness', 'Tempo', 'Valence', 'Key', 'Mode', 'Time Signature']

# Create dropdown options for albums
dropdown_options = []
for album in data['Album'].unique():
    for feature in features:
        dropdown_options.append({'label': album + ' - ' + feature, 'method': 'update', 'args': [{'x': [data[data['Album'] == album][feature]],
                                                                                                   'y': [data[data['Album'] == album][feature]],
                                                                                                   'name': album + ' - ' + feature}]})

# Create initial plot
fig = go.Figure()

# Add traces for each album-feature combination
for album in data['Album'].unique():
    for feature in features:
        fig.add_trace(go.Scatter(x=data[data['Album'] == album][feature],
                                 y=data[data['Album'] == album][feature],
                                 mode='lines',
                                 name=album + ' - ' + feature))

# Add dropdown menu for albums
fig.update_layout(updatemenus=[{'buttons': dropdown_options,
                                'direction': 'down',
                                'showactive': True,
                                'x': 0.1,
                                'xanchor': 'left',
                                'y': 1.15,
                                'yanchor': 'top'}])

# Update layout
fig.update_layout(title='Features Across Different Albums',
                  xaxis_title='Feature',
                  yaxis_title='Value')

# Show plot
fig.show()


# In[ ]:


# Get the most frequent songs
most_frequent_songs = data['Song'].value_counts().head(10)
print("Top 10 Most Frequent Songs:")
print(most_frequent_songs)


# In[ ]:


# Get the top 10 most frequent songs
top_songs = data['Song'].value_counts().head(10).index

# Filter the DataFrame to include only the rows corresponding to the top songs
top_songs_df = data[data['Song'].isin(top_songs)]

fig = px.bar(top_songs_df, x='Song', y='num_of_song_avaliable_markets',
             title='Number of Available Markets for Top 10 Most Frequent Songs',
             labels={'Song': 'Song', 'num_of_song_avaliable_markets': 'Number of Available Markets'})

fig.update_layout(xaxis={'categoryorder': 'total descending'})  # Sort x-axis by frequency
fig.show()


# In[ ]:


fig = px.scatter(data, x='Loudness', y='Artist(s) Genres', title='Loudness vs Genre')
fig.show()


# In[ ]:


fig = px.scatter(data, x='Popularity', y='Artist(s) Genres', title='Popularity vs Genre')
fig.show()


# In[ ]:


fig = px.scatter(data, x='Danceability', y='Valence', title='Valence vs Danceability',
                 marginal_x='histogram', marginal_y='histogram')
fig.show()


# In[ ]:


fig = px.scatter(data, x='Speechiness', y='Danceability', title='Speechiness vs Danceability')
fig.show()


# In[ ]:


fig1 = px.scatter(data, x='Energy', y='Valence', title='Valence vs Energy',
                 labels={'Energy': 'Energy', 'Valence': 'Valence'})
fig1.show()


# In[ ]:


fig2 = px.scatter(data, x='Speechiness', y='Valence', title='Valence vs Speechiness',
                 labels={'Speechiness': 'Speechiness', 'Valence': 'Valence'})
fig2.show()


# Not all features are correlated to each other, and even if correlated it's not a high correlation which results in an unmatched patterns as we see in plot which also make sense

# In[ ]:


fig = px.box(data, x='Key', y='Tempo', title='Average Tempo Distribution by Key', color_discrete_sequence=['brown'])
fig.update_layout(xaxis_title='Key', yaxis_title='Tempo')
fig.show()


# In[ ]:


df_sorted = data.sort_values(by='Hot100 Rank')
top_10 = df_sorted.head(10)
least_10 = df_sorted.tail(10)

combined_df = pd.concat([top_10, least_10])

fig = px.bar(combined_df, x='Song', y='Hot100 Rank', title='Top 10 vs Least 10 Songs by Hot100 Rank',
             color='Song', color_discrete_map={'top_10': 'blue', 'least_10': 'red'})
fig.update_layout(xaxis_title='Song', yaxis_title='Hot100 Rank')
fig.show()


# In[ ]:


# Group the data by 'decades' column and count the unique albums
albums_per_decade = data.groupby('Decade')['Album'].nunique().reset_index()

print(albums_per_decade)


# In[ ]:


albums_per_decade = data.groupby('Decade')['Album'].nunique().reset_index()

fig = px.bar(albums_per_decade, x='Decade', y='Album', title='Number of Albums Released Across Decades')
fig.update_layout(xaxis_title='Decades', yaxis_title='Number of Albums')
fig.show()


# In[ ]:


sorted_df = data.nlargest(10, 'Popularity')

# Create a bar plot
fig = px.bar(sorted_df, x='Song', y='Popularity', color='Season', title='Top 10 Songs and Their Seasons')
fig.update_layout(xaxis_title='Song', yaxis_title='Popularity')

# Show the plot
fig.show()


# In[ ]:


fig = px.box(data, x='isItCatchy', y='Popularity', title='Distribution of Popularity by Catchy Category')

# Set labels for axes
fig.update_xaxes(title_text='Catchy')
fig.update_yaxes(title_text='Popularity')

# Show the plot
fig.show()


# In[ ]:


# Plot the distribution of True and False values in the "fromTop1000Artist" column
plt.figure(figsize=(8, 6))
data['fromTop1000Artist'].value_counts().plot(kind='bar', color=['skyblue', 'salmon'])
plt.title('Distribution of True and False Values in fromTop1000Artist')
plt.xlabel('Value')
plt.ylabel('Count')
# Set ticks and labels
plt.xticks(ticks=[0, 1], labels=['False', 'True'], rotation=0)
plt.show()


# In[ ]:


top_artists = data[data['fromTop1000Artist']]['Artist Names'].value_counts().head(30)

plt.figure(figsize=(10, 6))
top_artists.plot(kind='bar', color='purple')
plt.title('Top Artists based on fromTop1000Artist')
plt.xlabel('Artist Name')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.show()


# In[ ]:


top_artists = data[data['fromTop1000Artist']]['Artist Names'].value_counts().head(30)

# Convert to DataFrame
top_artists_df = top_artists.reset_index()
top_artists_df.columns = ['Artist Name', 'Count']

# Plot the top artists using Plotly
fig = px.bar(top_artists_df, x='Artist Name', y='Count', color='Count',
             labels={'Count': ''},
             title='Top Artists based on fromTop1000Artist',
             template='plotly',
             height=500)
fig.update_layout(xaxis_tickangle=-45, yaxis=dict(ticks='', showticklabels=False))
fig.show()


# In[ ]:


top_artists_by_decade = data.groupby(['Decade', 'Artist Names']).size().reset_index(name='Count')
top_artists_by_decade = top_artists_by_decade.groupby('Decade').apply(lambda x: x.nlargest(10, 'Count')).reset_index(drop=True)

traces = []
for decade, artists in top_artists_by_decade.groupby('Decade'):
    trace = go.Bar(
        x=artists['Artist Names'],
        y=artists['Count'],
        name=decade,
        marker=dict(color=artists['Count'], colorscale='Viridis', line=dict(color='rgb(0,0,0)', width=1.5)),
        hovertemplate='<b>%{x}</b><br>Count: %{y}<extra></extra>'
    )
    traces.append(trace)

# Create dropdown menu
buttons = []
for decade in top_artists_by_decade['Decade'].unique():
    visible = [False] * len(top_artists_by_decade['Decade'].unique())
    visible[list(top_artists_by_decade['Decade'].unique()).index(decade)] = True
    button = dict(label=decade,
                  method='update',
                  args=[{'visible': visible},
                        {'title': f'Top Artists in {decade}'}])
    buttons.append(button)

layout = dict(title='Top Artists by Decade',
              xaxis=dict(title='Artist Names'),
              yaxis=dict(title='Count'),
              updatemenus=[dict(buttons=buttons,
                                direction='down',
                                pad={'r': 10, 't': 10},
                                showactive=True,
                                x=0.1,
                                xanchor='left',
                                y=1.1,
                                yanchor='top')])

fig = go.Figure(data=traces, layout=layout)
fig.show()


# In[ ]:


top_artists_by_decade = data.groupby(['Decade', 'Artist Names']).size().reset_index(name='Count')
top_artists_by_decade = top_artists_by_decade.groupby('Decade').apply(lambda x: x.nlargest(10, 'Count')).reset_index(drop=True)

traces = []
buttons = []
for i, (decade, artists) in enumerate(top_artists_by_decade.groupby('Decade')):
    colors = px.colors.qualitative.Plotly[:len(artists)]
    trace = go.Pie(
        labels=artists['Artist Names'],
        values=artists['Count'],
        hole=0.4,
        hoverinfo='label+percent',
        name=decade,
        marker=dict(colors=colors)
    )
    traces.append(trace)

    # Create button for dropdown menu
    visible = [False] * len(top_artists_by_decade)
    visible[i] = True
    button = dict(label=decade,
                  method='update',
                  args=[{'visible': visible},
                        {'title': f'Top Artists in {decade}'}])
    buttons.append(button)

# Create layout
layout = go.Layout(
    title='Top Artists by Decade',
    showlegend=True,
    annotations=[
        dict(
            text="Decades",
            x=0.5,
            y=-0.1,
            font=dict(size=20),
            showarrow=False
        )
    ],
    updatemenus=[
        dict(
            buttons=buttons,
            direction="down",
            pad={"r": 10, "t": 10},
            showactive=True,
            x=0.1,
            xanchor="left",
            y=1.1,
            yanchor="top"
        )
    ]
)

# Create figure
fig = go.Figure(data=traces, layout=layout)

# Show plot
fig.show()


# In[ ]:


# Filter only the rows where Album_isTop_1810 is True
top_albums_df = data[data['Album_isTop_1810']]

# Group by artist and count the number of top albums
top_album_counts = top_albums_df.groupby('Artist Names').size().reset_index(name='TopAlbumCount')

# Sort the artists by the count of top albums and select the top 10
top_20_artists = top_album_counts.nlargest(20, 'TopAlbumCount')

# Plotting
fig = px.bar(top_20_artists, x='TopAlbumCount', y='Artist Names', orientation='h',
             labels={'TopAlbumCount': 'Number of Top Albums', 'Artist Names': 'Artist Names'},
             title='Top 20 Artists with Most Top Albums')
fig.show()


# In[ ]:


# Create a dictionary from the DataFrame
artist_counts_dict = dict(zip(top_20_artists['Artist Names'], top_20_artists['TopAlbumCount']))

# Generate the word cloud
wordcloud = WordCloud(width=800, height=400, background_color='white').generate_from_frequencies(artist_counts_dict)

# Plot the word cloud
plt.figure(figsize=(10, 6))
plt.imshow(wordcloud, interpolation='bilinear')
plt.title('Top Artists with Most Top Albums')
plt.axis('off')
plt.show()


# In[ ]:


# Count the occurrences of each decade
decade_counts = data['Decade'].value_counts()

# Create a DataFrame for the pie chart
decade_counts_df = pd.DataFrame({'Decade': decade_counts.index, 'Count': decade_counts.values})

# Plot the distribution of decades using Plotly
fig = px.pie(decade_counts_df, values='Count', names='Decade',
             title='Distribution of Decades',
             hole=0.3,
             template='plotly_dark')
fig.show()


# In[ ]:


albums_per_decade = data.groupby('Decade')['Album'].nunique().reset_index()

fig = px.bar(albums_per_decade, x='Decade', y='Album', title='Number of Albums Released Across Decades')
fig.update_layout(xaxis_title='Decades', yaxis_title='Number of Albums')
fig.show()


# In[ ]:


data['Album Release Date'] = pd.to_datetime(data['Album Release Date'])

# Group by release date and count the number of songs
release_date_counts = data.groupby('Album Release Date').size().reset_index(name='SongCount')

# Plotting
plt.figure(figsize=(12, 6))
plt.plot(release_date_counts['Album Release Date'], release_date_counts['SongCount'], marker='o', linestyle='-')
plt.title('Trend of Songs Released Over Time')
plt.xlabel('Release Date')
plt.ylabel('Number of Songs')
plt.grid(True)
plt.show()


# In[ ]:


# Assuming 'Album Release Date' column is in datetime format
data['Album Release Date'] = pd.to_datetime(data['Album Release Date'])

# Group by release date and count the number of songs
release_date_counts = data.groupby('Album Release Date').size().reset_index(name='SongCount')

# Create an interactive time series graph with Plotly
fig = go.Figure()

fig.add_trace(go.Scatter(x=release_date_counts['Album Release Date'], y=release_date_counts['SongCount'],
                         mode='lines+markers', name='Number of Songs', line=dict(color='hotpink')))

# Customize layout
fig.update_layout(title='Trend of Songs Released Over Time',
                   xaxis_title='Release Date',
                   yaxis_title='Number of Songs',
                   hovermode='x unified')

fig.show()


# In[ ]:


# Get the top 10 most frequent songs
top_songs = data['Song'].value_counts().head(10).index

# Filter the DataFrame to include only the rows corresponding to the top songs
top_songs_df = data[data['Song'].isin(top_songs)]

fig = px.bar(top_songs_df, x='Song', y='num_of_song_avaliable_markets',
             title='Number of Available Markets for Top 10 Most Frequent Songs',
             labels={'Song': 'Song', 'num_of_song_avaliable_markets': 'Number of Available Markets'})

fig.update_layout(xaxis={'categoryorder': 'total descending'})  # Sort x-axis by frequency
fig.show()


# In[ ]:


popularity_threshold = data['Popularity'].quantile(0.75)

# Categorize popularity based on the threshold
data['Popularity_Category'] = pd.cut(data['Popularity'], bins=[0, popularity_threshold, data['Popularity'].max()], labels=['Low', 'High'])

# Create an interactive scatter plot
fig = px.scatter(data, x='Speechiness', y='Song Length(ms)', color='Popularity_Category',
                 title='Speechiness vs Song Length with Popularity Category',
                 labels={'Speechiness': 'Speechiness', 'Song Length': 'Song Length'},
                 width=800, height=500)

# Show the plot
fig.show()


# In[ ]:


season_counts = data['Season'].value_counts().reset_index()
season_counts.columns = ['Season', 'Total Songs']

# Create an interactive pie chart
fig = px.pie(season_counts, values='Total Songs', names='Season',
             title='Distribution of Songs Released in Each Season')

# Show the plot
fig.show()


# In[ ]:


df_sorted = data.sort_values(by='Hot100 Rank')
top_10 = df_sorted.head(10)
least_10 = df_sorted.tail(10)

combined_df = pd.concat([top_10, least_10])

fig = px.bar(combined_df, x='Song', y='Hot100 Rank', title='Top 10 vs Least 10 Songs by Hot100 Rank',
             color='Song', color_discrete_map={'top_10': 'blue', 'least_10': 'red'})
fig.update_layout(xaxis_title='Song', yaxis_title='Hot100 Rank')
fig.show()


# In[ ]:


# Sort DataFrame based on 'Popularity'
sorted_df = data.nlargest(10, 'Popularity')

# Create a bar plot
fig = px.bar(sorted_df, x='Song', y='Popularity', color='Season', title='Top 10 Songs and Their Seasons')
fig.update_layout(xaxis_title='Song', yaxis_title='Popularity')

# Show the plot
fig.show()


# In[ ]:


fig = px.box(data, x='isItCatchy', y='Popularity', title='Distribution of Popularity by Catchy Category')

# Set labels for axes
fig.update_xaxes(title_text='Catchy')
fig.update_yaxes(title_text='Popularity')

# Show the plot
fig.show()


# In[ ]:


# Filter only the rows where Album_isTop_1810 is True
top_albums_df = data[data['Album_isTop_1810']]

# Group by artist and count the number of top albums
top_album_counts = top_albums_df.groupby('Artist Names').size().reset_index(name='TopAlbumCount')

# Sort the artists by the count of top albums and select the top 10
top_20_artists = top_album_counts.nlargest(20, 'TopAlbumCount')

# Plotting
fig = px.bar(top_20_artists, x='TopAlbumCount', y='Artist Names', orientation='h',
             labels={'TopAlbumCount': 'Number of Top Albums', 'Artist Names': 'Artist Names'},
             title='Top 20 Artists with Most Top Albums')
fig.show()


# In[ ]:


top_artists = data[data['fromTop1000Artist']]['Artist Names'].value_counts().head(30)

# Convert to DataFrame
top_artists_df = top_artists.reset_index()
top_artists_df.columns = ['Artist Name', 'Count']

# Plot the top artists using Plotly
fig = px.bar(top_artists_df, x='Artist Name', y='Count', color='Count',
             labels={'Count': ''},
             title='Top Artists based on fromTop1000Artist',
             template='plotly',
             height=500)
fig.update_layout(xaxis_tickangle=-45, yaxis=dict(ticks='', showticklabels=False))
fig.show()


# In[ ]:


top_artists_by_decade = data.groupby(['Decade', 'Artist Names']).size().reset_index(name='Count')
top_artists_by_decade = top_artists_by_decade.groupby('Decade').apply(lambda x: x.nlargest(10, 'Count')).reset_index(drop=True)

traces = []
for decade, artists in top_artists_by_decade.groupby('Decade'):
    trace = go.Bar(
        x=artists['Artist Names'],
        y=artists['Count'],
        name=decade,
        marker=dict(color=artists['Count'], colorscale='Viridis', line=dict(color='rgb(0,0,0)', width=1.5)),
        hovertemplate='<b>%{x}</b><br>Count: %{y}<extra></extra>'
    )
    traces.append(trace)

# Create dropdown menu
buttons = []
for decade in top_artists_by_decade['Decade'].unique():
    visible = [False] * len(top_artists_by_decade['Decade'].unique())
    visible[list(top_artists_by_decade['Decade'].unique()).index(decade)] = True
    button = dict(label=decade,
                  method='update',
                  args=[{'visible': visible},
                        {'title': f'Top Artists in {decade}'}])
    buttons.append(button)

layout = dict(title='Top Artists by Decade',
              xaxis=dict(title='Artist Names'),
              yaxis=dict(title='Count'),
              updatemenus=[dict(buttons=buttons,
                                direction='down',
                                pad={'r': 10, 't': 10},
                                showactive=True,
                                x=0.1,
                                xanchor='left',
                                y=1.1,
                                yanchor='top')])

fig = go.Figure(data=traces, layout=layout)
fig.show()


# In[ ]:


top_artists_by_decade = data.groupby(['Decade', 'Artist Names']).size().reset_index(name='Count')
top_artists_by_decade = top_artists_by_decade.groupby('Decade').apply(lambda x: x.nlargest(10, 'Count')).reset_index(drop=True)

traces = []
buttons = []
for i, (decade, artists) in enumerate(top_artists_by_decade.groupby('Decade')):
    colors = px.colors.qualitative.Plotly[:len(artists)]
    trace = go.Pie(
        labels=artists['Artist Names'],
        values=artists['Count'],
        hole=0.4,
        hoverinfo='label+percent',
        name=decade,
        marker=dict(colors=colors)
    )
    traces.append(trace)

    # Create button for dropdown menu
    visible = [False] * len(top_artists_by_decade)
    visible[i] = True
    button = dict(label=decade,
                  method='update',
                  args=[{'visible': visible},
                        {'title': f'Top Artists in {decade}'}])
    buttons.append(button)

# Create layout
layout = go.Layout(
    title='Top Artists by Decade',
    showlegend=True,
    annotations=[
        dict(
            text="Decades",
            x=0.5,
            y=-0.1,
            font=dict(size=20),
            showarrow=False
        )
    ],
    updatemenus=[
        dict(
            buttons=buttons,
            direction="down",
            pad={"r": 10, "t": 10},
            showactive=True,
            x=0.1,
            xanchor="left",
            y=1.1,
            yanchor="top"
        )
    ]
)

# Create figure
fig = go.Figure(data=traces, layout=layout)

# Show plot
fig.show()


# # preprocessing & Cleansing

# In[ ]:


import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
import warnings
import os
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import OneHotEncoder
from scipy.stats import boxcox
import ast
sns.set()
warnings.filterwarnings(action='ignore')


# In[ ]:


df=pd.read_csv("Prepared Song Popularity.csv")


# In[ ]:


df.isnull().sum()


# In[ ]:


df.describe()


# In[ ]:


df.head(2)


# In[ ]:


df["Album Release Date"]=pd.to_datetime(df["Album Release Date"])
df["day"]=df["Album Release Date"].dt.day
df["month"]=df["Album Release Date"].dt.month
df["year"]=df["Album Release Date"].dt.year


# In[ ]:


categoricals=["isItCatchy","is_colorful","has_Potential","fromTop1000Artist","Mode","Decade","Season","Duration Category","Generes Clusters","Album_isTop_1810"]


# In[ ]:


non_object_cols = df.select_dtypes(exclude=['object']).columns
non_object_cols=non_object_cols.drop(["Unnamed: 0","isItCatchy","is_local","is_colorful","has_Potential","Album_isTop_1810","fromTop1000Artist","Mode","Generes Clusters","Album Release Date"])
non_object_cols


# In[ ]:


for col in non_object_cols:
    fig = plt.figure(figsize=(4,3))
    plt.title(f"{col}")
    df[col].hist()


# In[ ]:


for col in non_object_cols:
    fig, ax = plt.subplots(1,3,figsize=(15, 5))
    fig.suptitle(f"Histograms for {col}", fontsize=16)

    sns.histplot(df[col], ax=ax[0], color='red', label='default')
    ax[0].set_title('Original')

    sns.histplot(np.sqrt(df[col]), ax=ax[1], color='blue', label='Square Root')
    ax[1].set_title('Square Root')

    sns.histplot(np.log(df[col]), ax=ax[2], color='orange', label='Log')
    ax[2].set_title('Log')

    for axis in ax:
        axis.legend()

plt.show()


# In[ ]:


sns.heatmap(df[non_object_cols].corr())


# In[ ]:


correlation_df = pd.DataFrame(list(df[non_object_cols].corr()["Popularity"].sort_values().items()), columns=['Feature', 'Correlation'])
sns.barplot(x='Correlation', y='Feature', data=correlation_df, palette='viridis')


# In[ ]:


sns.boxplot(data=df[non_object_cols],palette='rainbow',orient='h')


# In[ ]:


sns.pairplot(df[non_object_cols])


# In[ ]:


def check_Percentage_Of_Outliers(DataFrame,column_name,ifRemove=False):
    rows=DataFrame.shape[0]

    q1=DataFrame[column_name].quantile(0.25)
    q2=DataFrame[column_name].quantile(0.5) # Median
    q3=DataFrame[column_name].quantile(0.75)

    IQR=q3-q1
    cut_off = IQR * 1.5
    lower,upper= q1 - cut_off, q3 + cut_off

    outliers_count=DataFrame[column_name][(DataFrame[column_name] < lower)].count()
    outliers_count+=DataFrame[column_name][(DataFrame[column_name] > upper)].count()
    if not ifRemove:
        print(f"Name = {column_name} , Percentage = {outliers_count/rows: 0.3%} , Count = {outliers_count}")
    if ifRemove :
        DataFrame[column_name]=DataFrame[column_name][(DataFrame[column_name] > lower)]
        DataFrame[column_name]=DataFrame[column_name][(DataFrame[column_name] < upper)]


# In[ ]:


for col in non_object_cols:
    plt.figure(figsize=(3, 2))
    sns.boxplot(x=df[col])
    check_Percentage_Of_Outliers(df,col)
    print("--------------------\n")


# In[ ]:


epsilon = 1e-8
def safe_log(x):
    return np.log(x + epsilon)
transformations = [
    None,
    np.log,
    None,
    np.sqrt,
    None,
    None,
    np.log,
    np.log,
    None,
    np.log,
    None,
    None,
    None,
    None,
    np.log,
    np.log,
    None,
    None,
    None,
    np.log,
    np.log,
    np.log,
    None,
    None,
    None,
]
transformations=[safe_log if func == np.log else func for func in transformations]


# In[ ]:


NewDF=pd.DataFrame()


# In[ ]:


for (transformation,col) in zip(transformations,non_object_cols):
    if col=="Loudness":
        NewDF[col]=df[col]
    if transformation!=None:
        NewDF[transformation.__name__+" "+col]=transformation(df[col])
    else :
        NewDF[col]=df[col]


# In[ ]:


NewDF.corr()["Popularity"].sort_values()


# In[ ]:


DFcategoricals=pd.get_dummies(df[categoricals]).astype(int)
DFcategoricals["is_local"]=df["is_local"].astype(int)


# In[ ]:


DFcategoricals


# In[ ]:


PreprocessedDF=pd.DataFrame()
for i in NewDF.columns:
    PreprocessedDF[i]=NewDF[i]
for i in DFcategoricals.columns:
    PreprocessedDF[i]=DFcategoricals[i]
df["Artist(s) Genres"][df["Artist(s) Genres"].isnull()]="[]"


# In[ ]:


Genres=dict()
cnt=0
for row in df["Artist(s) Genres"]:
    set_ = ast.literal_eval(row)
    genres_list = [genre.strip() for genre in set_]
    for genre in genres_list:
        if genre not in Genres:
            Genres[genre]=cnt
            cnt=cnt+1

matrix=np.zeros((df.shape[0],728))

cnt=0
for i in df["Artist(s) Genres"]:
    set_ = ast.literal_eval(i)
    genres_list = [genre.strip() for genre in set_]
    for genre in genres_list:
        matrix[cnt,Genres[genre]]=1
    cnt=cnt+1


# In[ ]:


df=df.reset_index()
PreprocessedDF=PreprocessedDF.reset_index()


# In[ ]:


PreprocessedDF[list(Genres.keys())]=pd.DataFrame(matrix,columns=list(Genres.keys()))


# In[ ]:


PreprocessedDF[['Song', 'Album', 'Artist Names']]=df[['Song', 'Album', 'Artist Names']]
PreprocessedDF[['Spotify Link', 'Song Image', 'Spotify URI']]=df[['Spotify Link', 'Song Image', 'Spotify URI']]
PreprocessedDF[["image_description","color_values"]]=df[["image_description","color_values"]]


# In[ ]:


PreprocessedDF


# In[ ]:


PreprocessedDF[NewDF.columns]


# In[ ]:


def Replace_Outliers(DataFrame,column_name):
    rows=DataFrame.shape[0]

    q1=DataFrame[column_name].quantile(0.25)
    q2=DataFrame[column_name].quantile(0.5) # Median
    q3=DataFrame[column_name].quantile(0.75)

    IQR=q3-q1
    cut_off = IQR * 1.5
    lower,upper= q1 - cut_off, q3 + cut_off


    outliers = DataFrame[(DataFrame[column_name] < lower) | (DataFrame[column_name] > upper)][column_name]
    mean_value = DataFrame[column_name].mean()
    DataFrame.loc[outliers.index, column_name] = mean_value


# In[ ]:


PreprocessedDF2=pd.DataFrame(PreprocessedDF)


# In[ ]:


for col in NewDF.columns:
    Replace_Outliers(PreprocessedDF2,col)


# In[ ]:


for col in NewDF.columns:
    plt.figure(figsize=(3, 2))
    sns.boxplot(x=PreprocessedDF2[col])
    check_Percentage_Of_Outliers(PreprocessedDF2,col)
    print("--------------------\n")


# In[ ]:


PreprocessedDF=PreprocessedDF.drop(["index"],axis=1)


# In[ ]:


PreprocessedDF2=PreprocessedDF2.drop(["index"],axis=1)


# In[ ]:


PreprocessedDF.to_csv("PreprocessedDF.csv")


# In[ ]:


PreprocessedDF2.to_csv("PreprocessedDF_WithoutOutliers.csv")


# # Feature Selection & Modeling

# In[1]:


get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


import pandas as pd


# In[1]:


import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score, cross_validate


from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.linear_model import SGDRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import ElasticNet
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import StackingRegressor
import xgboost as xgb

from sklearn import metrics
from sklearn.metrics import make_scorer
import pickle

class Regression:

    def GetAccuracies(self, model, y_pred_test, y_pred_train):

        mse_test = metrics.mean_squared_error(self.y_test, y_pred_test)
        mae_test = metrics.mean_absolute_error(self.y_test, y_pred_test)
        r2_score_test = metrics.r2_score(self.y_test, y_pred_test)

        mse_train = metrics.mean_squared_error(self.y_train, y_pred_train)
        mae_train = metrics.mean_absolute_error(self.y_train, y_pred_train)
        r2_score_train = metrics.r2_score(self.y_train, y_pred_train)

        return [model, mse_test, mae_test, r2_score_test * 100, mse_train, mae_train, r2_score_train * 100]


    def Linear_Regression(self):
        linear = LinearRegression()
        self.list_of_models_with_cross_validation.append(self.train_model('Linear_Regression', LinearRegression()))
        linear.fit(self.x_train, self.y_train)

        y_pred_test = linear.predict(self.x_test)
        y_pred_train = linear.predict(self.x_train)

        return self.GetAccuracies(linear, y_pred_test, y_pred_train)


    def LassoRegression(self):

        lasso_model = Lasso(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('LassoRegression', Lasso(random_state=42)))
        lasso_model.fit(self.x_train, self.y_train)

        y_pred_test = lasso_model.predict(self.x_test)
        y_pred_train = lasso_model.predict(self.x_train)

        return self.GetAccuracies(lasso_model, y_pred_test, y_pred_train)



    def RidgeRegression(self):

        ridge_model = Ridge(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('RidgeRegression',  Ridge(random_state=42)))
        ridge_model.fit(self.x_train, self.y_train)

        y_pred_test = ridge_model.predict(self.x_test)
        y_pred_train = ridge_model.predict(self.x_train)

        return self.GetAccuracies(ridge_model, y_pred_test, y_pred_train)



    def SGDRegression(self):
        sgd_model = SGDRegressor(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('SGDRegression', SGDRegressor(random_state=42)))
        sgd_model.fit(self.x_train, self.y_train)

        y_pred_test = sgd_model.predict(self.x_test)
        y_pred_train = sgd_model.predict(self.x_train)

        return self.GetAccuracies(sgd_model, y_pred_test, y_pred_train)

    def Polynomial_Regression(self):

        linear1 = LinearRegression()
        linear2 = LinearRegression()

        results1_v = self.train_model('Polynomial Regression', LinearRegression(), poly_degree = 2)
        results2_v = self.train_model('Polynomial Regression', LinearRegression(), poly_degree = 3)
        results1_v.append(2)
        results2_v.append(3)
        if(results1_v[2] < results2_v[2]):
            self.list_of_models_with_cross_validation.append(results1_v)
        else:
            self.list_of_models_with_cross_validation.append(results2_v)


        x_train_poly_degree2 = self.poly2.fit_transform(self.x_train)
        x_train_poly_degree3 = self.poly3.fit_transform(self.x_train)

        linear1.fit(x_train_poly_degree2, self.y_train)
        linear2.fit(x_train_poly_degree3, self.y_train)

        y_pred_test1 = linear1.predict(self.poly2.fit_transform(self.x_test))
        y_pred_test2 = linear2.predict(self.poly3.fit_transform(self.x_test))

        y_pred_train1 = linear1.predict(x_train_poly_degree2)
        y_pred_train2 = linear2.predict(x_train_poly_degree3)

        results1 = self.GetAccuracies(linear1, y_pred_test1, y_pred_train1)
        results2 = self.GetAccuracies(linear2, y_pred_test2, y_pred_train2)

        results1.append(2)
        results2.append(3)

        if(results1[4] > results2[4]):
           return results1
        return results2

    def SVR(self):

        svr_model = SVR(kernel='rbf')
        self.list_of_models_with_cross_validation.append(self.train_model('SVR', SVR(kernel='rbf')))
        svr_model.fit(self.x_train, self.y_train)

        y_pred_test = svr_model.predict(self.x_test)
        y_pred_train = svr_model.predict(self.x_train)

        return self.GetAccuracies(svr_model, y_pred_test, y_pred_train)


    def NeuralNetworkRegression(self):

        nn_model = MLPRegressor(random_state=42, max_iter=10000)
        self.list_of_models_with_cross_validation.append(self.train_model('NeuralNetworkRegression', MLPRegressor(random_state=42, max_iter=10000)))
        nn_model.fit(self.x_train, self.y_train)

        y_pred_test = nn_model.predict(self.x_test)
        y_pred_train = nn_model.predict(self.x_train)


        return self.GetAccuracies(nn_model, y_pred_test, y_pred_train)

    def GradientBoostingRegression(self):

        gb_model = GradientBoostingRegressor(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('GradientBoostingRegression', GradientBoostingRegressor(random_state=42)))
        gb_model.fit(self.x_train, self.y_train)

        y_pred_test = gb_model.predict(self.x_test)
        y_pred_train = gb_model.predict(self.x_train)

        return self.GetAccuracies(gb_model, y_pred_test, y_pred_train)


    def DecisionTreeRegression(self):

        dt_model = DecisionTreeRegressor(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('DecisionTreeRegression', DecisionTreeRegressor(random_state=42)))
        dt_model.fit(self.x_train, self.y_train)

        y_pred_test = dt_model.predict(self.x_test)
        y_pred_train = dt_model.predict(self.x_train)

        return self.GetAccuracies(dt_model, y_pred_test, y_pred_train)


    def ElasticNetRegression(self):

        en_model = ElasticNet(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('ElasticNetRegression', ElasticNet(random_state=42)))
        en_model.fit(self.x_train, self.y_train)

        y_pred_test = en_model.predict(self.x_test)
        y_pred_train = en_model.predict(self.x_train)


        return self.GetAccuracies(en_model, y_pred_test, y_pred_train)


    def RandomForestRegression(self):

        rf_model = RandomForestRegressor(n_estimators=8,max_depth=40, random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('RandomForestRegression', RandomForestRegressor(n_estimators=300, random_state=42)))
        rf_model.fit(self.x_train, self.y_train)

        y_pred_test = rf_model.predict(self.x_test)
        y_pred_train = rf_model.predict(self.x_train)

        return self.GetAccuracies(rf_model, y_pred_test, y_pred_train)

    def AdaBoostRegression(self):

        ab_model = AdaBoostRegressor(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('AdaBoostRegression', AdaBoostRegressor(random_state=42)))
        ab_model.fit(self.x_train, self.y_train)

        y_pred_test = ab_model.predict(self.x_test)
        y_pred_train = ab_model.predict(self.x_train)

        return self.GetAccuracies(ab_model, y_pred_test, y_pred_train)


    def BaggingRegression(self):

        bag_model = BaggingRegressor(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('BaggingRegression', BaggingRegressor(random_state=42)))
        bag_model.fit(self.x_train, self.y_train)

        y_pred_test = bag_model.predict(self.x_test)
        y_pred_train = bag_model.predict(self.x_train)

        return self.GetAccuracies(bag_model, y_pred_test, y_pred_train)

    def KNNLinearRegression(self):

        estimators = [
            ('knn', KNeighborsRegressor()),
            ('linear', LinearRegression())
        ]
        stack_model = StackingRegressor(estimators=estimators, final_estimator=LinearRegression())
        self.list_of_models_with_cross_validation.append(self.train_model('KNNLinearRegression', StackingRegressor(estimators=estimators, final_estimator=LinearRegression())))
        stack_model.fit(self.x_train, self.y_train)

        y_pred_test = stack_model.predict(self.x_test)
        y_pred_train = stack_model.predict(self.x_train)


        return self.GetAccuracies(stack_model, y_pred_test, y_pred_train)


    def XGBoostRegression(self):

        xgb_model = xgb.XGBRegressor(random_state=42)
        self.list_of_models_with_cross_validation.append(self.train_model('XGBoostRegression', xgb.XGBRegressor(random_state=42)))
        xgb_model.fit(self.x_train, self.y_train)

        y_pred_test = xgb_model.predict(self.x_test)
        y_pred_train = xgb_model.predict(self.x_train)

        return self.GetAccuracies(xgb_model, y_pred_test, y_pred_train)



    def FindBestModel(self):
        best = self.list_of_models_with_cross_validation[0]

        # for row in self.list_of_models_without_cross_validation:
        #     if(row[4] > best[4]):
        #         best = row

        for row in self.list_of_models_with_cross_validation:
            if(row[2] < best[2]):
                best = row

        return best


    def __GetTable(self, list_of_models):
        table_of_models = pd.DataFrame(columns=['name of model','Model','MSE for test', 'MAE for test', 'r2_score for test','MSE for train', 'MAE for train', 'r2_score for train', 'Polynomial Degree'])
        for row in list_of_models:
            if len(row) == 8: row.append(None) # degree
            table_of_models.loc[len(table_of_models)] = row
        table_of_models.sort_values(by=['r2_score for test','MSE for test','r2_score for train','MSE for train'], ascending=[False, True, False, True], inplace = True)
        table_of_models.drop(columns=['Model',],inplace=True)
        table_of_models.reset_index(drop=True, inplace=True)
        return table_of_models


    def __GetWithoutValidationTable(self):
        return self.__GetTable(self.list_of_models_without_cross_validation)

    def __GetWithValidationTable(self):
        return self.__GetTable(self.list_of_models_with_cross_validation)

    def train_model(self, model_name ,model, poly_degree = 1):

        train_data = None

        if poly_degree == 1:
            train_data = self.X
        elif poly_degree == 2:
            train_data = self.X_poly_degree2
        else:
            train_data = self.X_poly_degree3

        cv_results = cross_validate(model, train_data, self.Y, cv=self.k, scoring=self.scoring, return_train_score=True)

        return [
            model_name,                       #0
            model,                            #1
            -np.mean(cv_results['test_MSE']), #2    <-- validation loss
            -np.mean(cv_results['test_MAE']), #3
            np.mean(cv_results['test_R2']) * 100, #4
            -np.mean(cv_results['train_MSE']),    #5
            -np.mean(cv_results['train_MAE']),    #6
            np.mean(cv_results['train_R2']) * 100 ]   #7
            # poly degree                             #8

    def __init__(self, X, Y):

        scalar = StandardScaler()
        scalar.fit(X)

        self.X = scalar.transform(X)
        self.Y = Y

        self.x_train, self.x_test, self.y_train, self.y_test = train_test_split(X, Y, test_size=0.20, shuffle=True, random_state=42)
        self.poly2 = PolynomialFeatures(degree = 2)
        self.poly3 = PolynomialFeatures(degree = 3)
        self.X_poly_degree2 = self.poly2.fit_transform(self.X)
        self.X_poly_degree3 = self.poly3.fit_transform(self.X)

        self.k = 5 # for k-fold cross validation

        self.scoring = {'R2': make_scorer(metrics.r2_score),
                        'MSE': make_scorer(metrics.mean_squared_error, greater_is_better=False),
                        'MAE': make_scorer(metrics.mean_absolute_error, greater_is_better=False)}

        self.list_of_models_with_cross_validation = []
        # index: 0             1     2        3        4       5         6         7        8
        # value: name_of_model model MSE_test MAE_test r2_test MSE_train MAE_train r2_train poly_degree
        self.list_of_models_without_cross_validation = [
            ["Linear_Regression", *self.Linear_Regression()],
            ["LassoRegression", *self.LassoRegression()],
            ["RidgeRegression", *self.RidgeRegression()],
            ["SGDRegression", *self.SGDRegression()],
            ["Polynomial_Regression", *self.Polynomial_Regression()],
            ["SVR", *self.SVR()],
            ["NeuralNetworkRegression", *self.NeuralNetworkRegression()],
            ["GradientBoostingRegression", *self.GradientBoostingRegression()],
            ["DecisionTreeRegression", *self.DecisionTreeRegression()],
            ["ElasticNetRegression", *self.ElasticNetRegression()],
            ["RandomForestRegression", *self.RandomForestRegression()],
            ["AdaBoostRegression", *self.AdaBoostRegression()],
            ["BaggingRegression", *self.BaggingRegression()],
            ["KNNLinearRegression", *self.KNNLinearRegression()],
            ["XGBoostRegression", *self.XGBoostRegression()]]

        self.best_model = self.FindBestModel()

        self.with_validation_table = self.__GetWithValidationTable()
        self.without_validation_table = self.__GetWithoutValidationTable()

        # print(self.with_validation_table.head(len(self.with_validation_table)))
        # print(self.without_validation_table.head(len(self.without_validation_table)))

        filename = f"{self.best_model[0]}{self.best_model[4]}"

        if self.best_model[0] == 'Polynomial_Regression':
            filename += f" with degree = {self.best_model[len(self.best_model) - 1]}.pkl"
        else:
            filename += ".pkl"

        with open(filename, "wb") as file:
            pickle.dump(self.best_model[1], file)


# In[3]:


data=pd.read_csv("PreprocessedDF_WithoutOutliers.csv")


# In[4]:


data.head()


# In[5]:


data.drop(['Unnamed: 0','index','color_values','image_description','Spotify URI','Song Image','Spotify Link','Artist Names','Album','Song','is_local'], axis=1,inplace =True)


# In[6]:


x=data.drop(['Popularity'], axis =1)
y=data['Popularity']


# ##Stepwise Regression

# In[ ]:


import numpy as np
import pandas as pd
import statsmodels.api as sm

def stepwise_selection(X, y,
                       threshold_in=0.01,
                       threshold_out=0.05,
                       verbose=True):
    """ Perform a forward-backward feature selection
    based on p-value from statsmodels.api.OLS
    Arguments:
        X - pandas.DataFrame with candidate features
        y - list-like with the target
        threshold_in - include a feature if its p-value < threshold_in
        threshold_out - exclude a feature if its p-value > threshold_out
        verbose - whether to print the sequence of inclusions and exclusions
    Returns: list of selected features
    Always set threshold_in < threshold_out to avoid infinite looping.
    """

    included = []
    while True:
        changed = False
        # Forward step
        excluded = list(set(X.columns) - set(included))
        new_pval = pd.Series(index=excluded)
        for new_column in excluded:
            model = sm.OLS(y, sm.add_constant(pd.DataFrame(X[included + [new_column]]))).fit()
            new_pval[new_column] = model.pvalues[new_column]
        best_pval = new_pval.min()
        if best_pval < threshold_in:
            best_feature = new_pval.idxmin()
            included.append(best_feature)
            changed = True
            if verbose:
                print('Add  {:30} with p-value {:.6}'.format(best_feature, best_pval))

        # Backward step
        model = sm.OLS(y, sm.add_constant(pd.DataFrame(X[included]))).fit()
        # Use all coefficients except intercept
        pvalues = model.pvalues.iloc[1:]
        worst_pval = pvalues.max()  # Null if pvalues is empty
        if worst_pval > threshold_out:
            break

        if not changed:
            break

    return included


selected_features = stepwise_selection(x, y)

print('Selected features:')
print(selected_features)


# In[9]:


selected_features=['Loudness', 'fromTop1000Artist', 'safe_log Genres count', 'safe_log number of characters of the song name', 'Album_isTop_1810', 'karaoke', 'sqrt Acousticness', 'instrumental funk', 'Hot100 Rank', 'safe_log Instrumentalness', 'easy listening', 'swing', 'Decade_new millennium', 'pop', 'num_of_song_avaliable_markets', 'bubblegum pop', 'rhythm and blues', 'deep adult standards', 'dance pop', 'motown', 'rap', 'contemporary country', 'Decade_Seventies', 'safe_log total weight of genres', 'safe_log Weight', 'indie soul', 'modern country pop', 'permanent wave', 'torch song', 'british dance band', 'Season_Spring', 'vocal harmony group', 'safe_log Liveness', 'Valence', 'Danceability', 'canzone napoletana', 'new jack swing', 'hyperpop', 'adult standards', 'eurodance', 'electropop', 'colombian pop', 'Decade_Eighties', 'latin hip hop', 'year', 'Hot100 Ranking Year', 'Decade_Fifties']
X=x[selected_features]


# In[10]:


models=Regression(X,y)


# In[11]:


models.without_validation_table.head(len(models.without_validation_table))


# In[12]:


models.with_validation_table.head(len(models.with_validation_table))


# ## best k

# In[7]:


import numpy as np
from sklearn.datasets import make_regression
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.tree import DecisionTreeRegressor


# Define the number of features to select
k_features = 30

# Step 1: Use SelectKBest with F-test for regression to select top k features
selector = SelectKBest(score_func=f_regression, k=k_features)
X_selected = selector.fit_transform(x, y)

# Step 2: Fit a decision tree regressor on the selected features to compute feature importance
tree = DecisionTreeRegressor(random_state=42)
tree.fit(X_selected, y)

# Step 3: Get feature importance scores from the decision tree regressor
importance_scores = tree.feature_importances_

# Step 4: Select top k features based on importance scores
top_k_indices = np.argsort(importance_scores)[::-1][:k_features]
selected_features = X_selected[:, top_k_indices]

# Print selected feature indices and importance scores
print("Selected feature indices:", top_k_indices)
print("Importance scores:", importance_scores[top_k_indices])
print("Selected features (subset of X):")
print(selected_features)


# In[8]:


X=selected_features
models=Regression(X,y)


# In[9]:


models.without_validation_table.head(len(models.without_validation_table))


# In[10]:


models.with_validation_table.head(len(models.with_validation_table))


# ##VarianceThreshold

# In[11]:


import numpy as np
from sklearn.feature_selection import VarianceThreshold

# Define the variance threshold
threshold_value = 0.1  # Adjust this threshold as needed

# Step 1: Initialize VarianceThreshold with the specified threshold
selector = VarianceThreshold(threshold=threshold_value)

# Step 2: Fit the selector to the data and transform the data
X_selected = selector.fit_transform(x)

# Step 3: Get the indices of the selected features
selected_indices = selector.get_support(indices=True)

# Print selected feature indices
print("Selected feature indices:", selected_indices)
print("Selected features (subset of X):")
print(X_selected)


# In[12]:


X=X_selected
models=Regression(X,y)


# In[13]:


models.without_validation_table.head(len(models.without_validation_table))


# In[14]:


models.with_validation_table.head(len(models.with_validation_table))


# ## mutual info

# In[15]:


import numpy as np
from sklearn.datasets import make_regression
from sklearn.feature_selection import SelectKBest, mutual_info_regression



# Define the number of features to select
k_features = 30

# Step 1: Use SelectKBest with mutual information for regression to select top k features
selector = SelectKBest(score_func=mutual_info_regression, k=k_features)
X_selected = selector.fit_transform(x, y)

# Step 2: Get the indices of the selected features
selected_indices = selector.get_support(indices=True)

# Print selected feature indices
print("Selected feature indices:", selected_indices)
print("Selected features (subset of X):")
print(X_selected)


# In[16]:


X=X_selected
models=Regression(X,y)


# In[17]:


models.without_validation_table.head(len(models.without_validation_table))


# In[18]:


models.with_validation_table.head(len(models.with_validation_table))


# ## chi square

# In[19]:


import numpy as np
from sklearn.datasets import make_classification
from sklearn.feature_selection import SelectKBest, chi2


# Ensure that features are non-negative for chi-squared test
X = np.abs(x)

# Define the number of features to select
k_features = 10

# Step 1: Use SelectKBest with chi-squared test to select top k features
selector = SelectKBest(score_func=chi2, k=k_features)
X_selected = selector.fit_transform(X, y)

# Step 2: Get the indices of the selected features
selected_indices = selector.get_support(indices=True)

# Print selected feature indices
print("Selected feature indices:", selected_indices)
print("Selected features (subset of X):")
print(X_selected)


# In[20]:


X=X_selected
models=Regression(X,y)


# In[21]:


models.without_validation_table.head(len(models.without_validation_table))


# In[22]:


models.with_validation_table.head(len(models.with_validation_table))


# ## Domain Selection

# In[23]:


x.columns[:70]


# In[24]:


selected=['Hot100 Rank', 'safe_log Song Length(ms)', 'sqrt Acousticness',
       'Danceability', 'Energy', 'safe_log Instrumentalness',
       'safe_log Liveness', 'Loudness', 'safe_log Speechiness', 'Tempo',
       'Valence', 'Key', 'Time Signature',
       'safe_log number of words of the song name',
       'safe_log number of characters of the song name',
       'num_of_song_avaliable_markets', 'Hot100 Ranking Year',
       'number of song image details', 'safe_log Genres count',
       'safe_log Weight', 'safe_log total weight of genres', 'day', 'month',
       'year', 'isItCatchy', 'is_colorful', 'has_Potential',
       'fromTop1000Artist', 'Mode', 'Generes Clusters', 'Album_isTop_1810',
       'Decade_Eighties', 'Decade_Fifties', 'Decade_Fourties',
       'Decade_Nighnties', 'Decade_Old', 'Decade_Seventies', 'Decade_Sixties',
       'Decade_Thirties', 'Decade_new millennium', 'Season_Autumn',
       'Season_Spring', 'Season_Summer', 'Season_Winter',
       'Duration Category_average_time', 'Duration Category_large_time',
       'Duration Category_small_time']


# In[25]:


X=x[selected]
models=Regression(X,y)


# In[26]:


models.without_validation_table.head(len(models.without_validation_table))


# In[27]:


models.with_validation_table.head(len(models.with_validation_table))


# ## Hyper parameter tunning to the best models with our data

# In[9]:


import numpy as np
import pandas as pd
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
import xgboost as xgb
from sklearn.metrics import mean_squared_error


# In[10]:


selected_features=['Loudness', 'fromTop1000Artist', 'safe_log Genres count', 'safe_log number of characters of the song name', 'Album_isTop_1810', 'karaoke', 'sqrt Acousticness', 'instrumental funk', 'Hot100 Rank', 'safe_log Instrumentalness', 'easy listening', 'swing', 'Decade_new millennium', 'pop', 'num_of_song_avaliable_markets', 'bubblegum pop', 'rhythm and blues', 'deep adult standards', 'dance pop', 'motown', 'rap', 'contemporary country', 'Decade_Seventies', 'safe_log total weight of genres', 'safe_log Weight', 'indie soul', 'modern country pop', 'permanent wave', 'torch song', 'british dance band', 'Season_Spring', 'vocal harmony group', 'safe_log Liveness', 'Valence', 'Danceability', 'canzone napoletana', 'new jack swing', 'hyperpop', 'adult standards', 'eurodance', 'electropop', 'colombian pop', 'Decade_Eighties', 'latin hip hop', 'year', 'Hot100 Ranking Year', 'Decade_Fifties']
X=x[selected_features]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# ### GradientBoostingRegression

# In[11]:



# GradientBoostingRegressor
gb = GradientBoostingRegressor(random_state=42)
gb_param_grid = {
    'n_estimators': [100, 200, 300],
    'learning_rate': [0.05, 0.1, 0.2],
    'max_depth': [3, 5, 7],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['auto', 'sqrt', 'log2']
}



# In[12]:


gb_random_search = RandomizedSearchCV(gb, gb_param_grid, n_iter=50, cv=5, scoring='neg_mean_squared_error', random_state=42, n_jobs=-1)
gb_random_search.fit(X_train, y_train)
print("Best Parameters for GradientBoostingRegressor:", gb_random_search.best_params_)


# ### Random Forest

# In[13]:


# RandomForestRegressor
rf = RandomForestRegressor(random_state=42)
rf_param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['auto', 'sqrt', 'log2']
}


# In[14]:


rf_grid_search = GridSearchCV(rf, rf_param_grid, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
rf_grid_search.fit(X_train, y_train)
print("Best Parameters for RandomForestRegressor:", rf_grid_search.best_params_)


# ### XGBoostRegression

# In[15]:


# XGBoostRegressor
xgb_reg = xgb.XGBRegressor(random_state=42)
xgb_param_grid = {
    'n_estimators': [100, 200, 300],
    'learning_rate': [0.05, 0.1, 0.2],
    'max_depth': [3, 5, 7],
    'min_child_weight': [1, 3, 5],
    'gamma': [0, 0.1, 0.2],
    'subsample': [0.8, 1.0],
    'colsample_bytree': [0.8, 1.0]
}


# In[16]:


xgb_random_search = RandomizedSearchCV(xgb_reg, xgb_param_grid, n_iter=50, cv=5, scoring='neg_mean_squared_error', random_state=42, n_jobs=-1)
xgb_random_search.fit(X_train, y_train)
print("Best Parameters for XGBRegressor:", xgb_random_search.best_params_)


# In[17]:


from sklearn.metrics import r2_score

def evaluate_model(model, X_train, y_train, X_test, y_test):
    # Predict on training set
    y_train_pred = model.predict(X_train)
    # Predict on test set
    y_test_pred = model.predict(X_test)

    # Calculate MSE for training and testing
    train_mse = mean_squared_error(y_train, y_train_pred)
    test_mse = mean_squared_error(y_test, y_test_pred)

    # Calculate R2 score for training and testing
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)

    return train_mse, test_mse, train_r2, test_r2

# Evaluate RandomForestRegressor
best_rf = rf_grid_search.best_estimator_
rf_train_mse, rf_test_mse, rf_train_r2, rf_test_r2 = evaluate_model(best_rf, X_train, y_train, X_test, y_test)
print("RandomForestRegressor:")
print("  Training MSE:", rf_train_mse)
print("  Testing MSE:", rf_test_mse)
print("  Training R2 Score:", rf_train_r2)
print("  Testing R2 Score:", rf_test_r2)

# Evaluate GradientBoostingRegressor
best_gb = gb_random_search.best_estimator_
gb_train_mse, gb_test_mse, gb_train_r2, gb_test_r2 = evaluate_model(best_gb, X_train, y_train, X_test, y_test)
print("\nGradientBoostingRegressor:")
print("  Training MSE:", gb_train_mse)
print("  Testing MSE:", gb_test_mse)
print("  Training R2 Score:", gb_train_r2)
print("  Testing R2 Score:", gb_test_r2)

# Evaluate XGBRegressor
best_xgb = xgb_random_search.best_estimator_
xgb_train_mse, xgb_test_mse, xgb_train_r2, xgb_test_r2 = evaluate_model(best_xgb, X_train, y_train, X_test, y_test)
print("\nXGBRegressor:")
print("  Training MSE:", xgb_train_mse)
print("  Testing MSE:", xgb_test_mse)
print("  Training R2 Score:", xgb_train_r2)
print("  Testing R2 Score:", xgb_test_r2)


# ###  - Final Modeling

# In[1]:


import pandas as pd
import os
import numpy as np
import xgboost as xgb
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import seaborn as sns
sns.set()


# In[2]:


def XGBoostRegression():
        xgbreg=xgb.XGBRegressor(max_depth=5,n_estimators=40)
        xgbreg.fit(x_train,y_train)
        
        y_train_pred = xgbreg.predict(x_train)
        r2_train = r2_score(y_train, y_train_pred)
        print("R2 score on training set:", r2_train)

        y_test_pred = xgbreg.predict(x_test)
        r2_test = r2_score(y_test, y_test_pred)
        print("R2 score on test set:", r2_test)
        return xgbreg


# In[3]:


df=pd.read_csv('PreprocessedDF_WithoutOutliers.csv')
df=df.drop(["Unnamed: 0","Song","Album","Artist Names","Spotify Link","Song Image","Spotify URI","image_description","color_values"],axis=1)
df=df.drop(["Generes Clusters","Duration Category_large_time","Decade_Nighnties","number of song image details","day","Season_Summer","isItCatchy"],axis=1)


# In[4]:


correlation_df = pd.DataFrame(list(df.iloc[:,:50].corr()["Popularity"].sort_values().items()), columns=['Feature', 'Correlation'])
sns.barplot(x='Correlation', y='Feature', data=correlation_df, palette='viridis')


# In[5]:


for i in df.columns:
    if i !="Popularity":
        print(i)


# In[6]:


y=np.array(df["Popularity"])
x=np.array(df.drop(["Popularity","gender"],axis=1))


# In[7]:


x_train,x_test,y_train,y_test = train_test_split(x, y, test_size=0.10, shuffle=True, random_state=42)


# In[8]:


model=XGBoostRegression()


# In[9]:


import pickle
with open(f"XGB_Regression.pkl", "wb") as file:
            pickle.dump(model,file)

